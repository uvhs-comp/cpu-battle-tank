# cpu-battle-tank
Little Man Computer Battle Tank Game

Please see the project wiki homepage here: https://github.com/pddring/cpu-battle-tank/wiki

The idea is to create a fun game that can be a practical application for trying out low level assembler code on a Little Man Computer CPU.

It's designed for students studying GCSE Computer Science at Manor CE Academy, York.

To test out the latest stable version, click here: http://pddring.github.io/cpu-battle-tank/
